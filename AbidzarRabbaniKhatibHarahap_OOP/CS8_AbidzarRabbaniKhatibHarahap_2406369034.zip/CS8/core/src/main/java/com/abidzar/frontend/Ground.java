package com.abidzar.frontend;

public class Ground {
    private float topY = 50f;

    public void update(float cameraX) {

    }

    public float getTopY() {
        return topY;
    }
}
